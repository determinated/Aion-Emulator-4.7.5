﻿ALTER TABLE `account_data`
MODIFY COLUMN `balance`  float NULL AFTER `toll`;